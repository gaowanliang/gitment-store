#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import Flask, request, abort, jsonify
import requests

from plg import *
app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def hello_world():
    abort(404)


@app.route('/new', methods=['GET', 'POST'])
def new():
    text = request.args.get('qq')
    print(text)
    vmess = new_user(text)
    if "vmess" in vmess:
        v2_restart()
        r = requests.post("https://paste.gwliang.com/", data={
            "p": vmess[5:-4],
            "expiry": "PT5M",
            "lang": "text"
        })
        return jsonify({"info": r.url})
        # return jsonify({"info": vmess[5:-4]})
    else:
        return jsonify({"info": vmess})


@app.route('/get', methods=['GET', 'POST'])
def get():
    text = request.args.get('qq')
    print(text)
    vmess = get_vmess(text)
    print(vmess)
    if "vmess" in vmess:
        r = requests.post("https://paste.gwliang.com/", data={
            "p": vmess[5:-4],
            "expiry": "PT5M",
            "lang": "text"
        })

        return jsonify({"info": r.url})
    else:
        return jsonify({"info": vmess})


@app.route('/start', methods=['GET', 'POST'])
def start():
    text = request.args.get('qq')
    print(text)
    vmess = start_vmess(text)
    return jsonify({"info": vmess})


@app.route('/stop', methods=['GET', 'POST'])
def stop():
    text = request.args.get('qq')
    print(text)
    vmess = stop_vmess(text)
    return jsonify({"info": vmess})


if __name__ == '__main__':
    # 设置debug=True是为了让代码修改实时生效，而不用每次重启加载
    app.run(debug=True, port=36500, host="0.0.0.0")
