#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import random
import re
import string
import subprocess
import base64
import json

from v2ray_util import run_type
from v2ray_util.util_core.group import SS, Mtproto, Socks, Trojan, Vless, Vmess
from v2ray_util.util_core.loader import Loader
from v2ray_util.util_core.selector import (ClientSelector, CommonSelector,
                                           GroupSelector)
from v2ray_util.util_core.utils import (ColorStr, StreamType, clean_iptables,
                                        is_email, port_is_use, random_email,
                                        random_port, readchar, xtls_flow)
from v2ray_util.util_core.v2ray import V2ray, restart
from v2ray_util.util_core.writer import GlobalWriter, NodeWriter, GroupWriter, StreamWriter, ClientWriter


class StatsFactory:
    def __init__(self, door_port):
        self.door_port = door_port
        self.downlink_value = 0
        self.uplink_value = 0

    def __run_command(self, command):
        value = 0
        result = bytes.decode(subprocess.run(
            command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip())
        result_list = re.findall(r"\s+\d+\s+", result)
        if "v2ctl" not in result and len(result_list) == 1:
            value = int(result_list[0])
        return value

    def get_stats(self, meta_info, is_reset=False, is_group=False):
        is_reset = "true" if is_reset else "false"

        stats_cmd = "cd /usr/bin/v2ray && ./v2ctl api --server=127.0.0.1:{} StatsService.GetStats 'name: \"{}>>>{}>>>traffic>>>{}\" reset: {}'"

        if run_type == "xray":
            stats_cmd = "cd /usr/bin/xray && ./xray api stats --server=127.0.0.1:{} StatsService.GetStats 'name: \"{}>>>{}>>>traffic>>>{}\" reset: {}'"
        type_tag = ("inbound" if is_group else "user")

        stats_real_cmd = stats_cmd.format(
            str(self.door_port), type_tag, meta_info, "downlink", is_reset)
        self.downlink_value = self.__run_command(stats_real_cmd)

        stats_real_cmd = stats_cmd.format(
            str(self.door_port), type_tag, meta_info, "uplink", is_reset)
        self.uplink_value = self.__run_command(stats_real_cmd)

    def print_stats(self, horizontal=False):
        data = {
            "downlink": self.downlink_value,
            "uplink": self.uplink_value,
            "total": self.downlink_value + self.uplink_value
        }
        return data


def new_user(qq):
    gs = GroupSelector(_('add user'))
    group = gs.group
    group_list = gs.group_list

    if group == None:
        pass
    else:
        email = ""
        if type(group.node_list[0]) in (Vmess, Vless, Trojan):
            is_duplicate_email = False
            email = qq+"@q.n"

            if not is_email(email):
                print(_("not email, please input again"))
                return

            for loop_group in group_list:
                for node in loop_group.node_list:

                    if node.user_info == None or node.user_info == '':
                        continue
                    elif node.user_info == email:
                        return (_("have same email, please input other"))
                        is_duplicate_email = True
                        break
            # if not is_duplicate_email:
                # return

            nw = NodeWriter(group.tag, group.index)
            info = {'email': email}
            nw.create_new_user(**info)
            return get_vmess(qq)


def get_vmess(qq):
    gs = GroupSelector(_('add user'))
    group = gs.group
    group_list = gs.group_list

    if group == None:
        return
    else:
        email = ""
        if type(group.node_list[0]) in (Vmess, Vless, Trojan):
            is_duplicate_email = False
            email = qq+"@q.n"

            if not is_email(email):
                print(_("not email, please input again"))
                return

            for loop_group in group_list:
                for node in loop_group.node_list:
                    if node.user_info == None or node.user_info == '':
                        continue
                    elif node.user_info == email:
                        return node.link(loop_group.ip, loop_group.port, loop_group.tls)
    return


def get_traffic(qq):
    loader = Loader()
    profile = loader.profile
    group_list = profile.group_list
    data = {}
    sf = StatsFactory(profile.stats.door_port)
    for group in group_list:
        port_way = "-{}".format(group.end_port) if group.end_port else ""
        for node in group.node_list:
            print(node.user_info)
            if node.user_info:
                sf.get_stats(node.user_info, False)
                if node.user_info == qq+"@q.n":
                    return sf.print_stats(horizontal=True)
                data[node.user_info] = sf.print_stats(horizontal=True)
            else:
                print(ColorStr.yellow(_("no effective email!!!")))
    return data


def set_port(new_port_info):
    new_port_info = str(new_port_info)
    gs = GroupSelector(_('modify port'))
    group = gs.group

    if group == None:
        pass
    if new_port_info.isdecimal() or re.match(r'^\d+\-\d+$', new_port_info):
        gw = GroupWriter(group.tag, group.index)
        gw.write_port(new_port_info)
        print(_('port modify success!'))
        return True
    else:
        print(_("input error!"))


def set_stream():
    sw = StreamWriter('A', -1, StreamType.TCP_HOST)
    kw = {
        'host': "www.bilibili.com"
    }
    sw.write(**kw)


def stop_vmess(qq):
    loader = Loader()
    profile = loader.profile
    group_list = profile.group_list
    find = False
    email = qq+"@q.n"

    for _group in group_list:
        if find:
            break
        for index, node in enumerate(_group.node_list):
            if node.user_info == email:
                client_index = index
                group = _group
                find = True
                break

    if group == None:
        pass
    else:
        if type(group.node_list[client_index]) == Vmess:
            old_uuid = group.node_list[client_index].password
            if group.node_list[client_index].alter_id == 233:
                return False

            print("{}: {}".format(_("node UUID"),
                  group.node_list[client_index].password))
            new_uuid = add_uuid(old_uuid)
            print("{}: {}".format(_("new UUID"), new_uuid))
            cw = ClientWriter(group.tag, group.index, client_index)
            cw.write_uuid(new_uuid)
            cw.write_aid(233)
            print(_("UUID modify success!"))
            V2ray.restart()
            return True


def start_vmess(qq):
    loader = Loader()
    profile = loader.profile
    group_list = profile.group_list
    find = False
    email = qq+"@q.n"

    for _group in group_list:
        if find:
            break
        for index, node in enumerate(_group.node_list):
            if node.user_info == email:
                client_index = index
                group = _group
                find = True
                break

    if group == None:
        pass
    else:
        if type(group.node_list[client_index]) == Vmess:
            old_uuid = group.node_list[client_index].password
            if group.node_list[client_index].alter_id != 233:
                return False

            print("{}: {}".format(_("node UUID"),
                  group.node_list[client_index].password))
            new_uuid = sub_uuid(old_uuid)
            print("{}: {}".format(_("new UUID"), new_uuid))
            cw = ClientWriter(group.tag, group.index, client_index)
            cw.write_uuid(new_uuid)
            cw.write_aid(0)
            print(_("UUID modify success!"))
            V2ray.restart()
            return True


def v2_restart():
    V2ray.restart()


def add_uuid(text):
    a = ["0", "1", "2", "3", "4", "5", '6', '7',
         '8', '9', "a", 'b', 'c', 'd', 'e', 'f']
    p = ""
    for i in text:
        if i != "-":
            oo = a.index(i)
            if oo == 0:
                p += 'f'
            else:
                p += a[oo-1]
        else:
            p += "-"
    return p


def sub_uuid(text):
    a = ["0", "1", "2", "3", "4", "5", '6', '7',
         '8', '9', "a", 'b', 'c', 'd', 'e', 'f']
    p = ""
    for i in text:
        if i != "-":
            oo = a.index(i)
            if oo == 15:
                p += '0'
            else:
                p += a[oo+1]
        else:
            p += "-"
    return p


if __name__ == "__mains__":
    # print(new_user("1234567"))
    loader = Loader()
    profile = loader.profile
    group_list = profile.group_list
    DEL_UPDATE_TIMER_CMD = "crontab -l|sed '/SHELL=/d;/{}/d' > crontab.txt && crontab crontab.txt >/dev/null 2>&1 && rm -f crontab.txt >/dev/null 2>&1".format(
        run_type)
    print(profile.stats.status)

    if not profile.stats.status:
        os.system(DEL_UPDATE_TIMER_CMD)
        gw = GlobalWriter(group_list)
        gw.write_stats(True)
        V2ray.restart()
        print(_("open traffic statistics success!"))
    # print(get_traffic("123456"))


if __name__ == "__main1__":
    # set_port(8080)
    set_stream()
    V2ray.restart()

if __name__ == "__main__":
    # print(new_user("1234567"))
    # stop_vmess("1234567")
    start_vmess("1234567")
    # print(sub_uuid(add_uuid("f51ff080-b491-11eb-80e6-002248559c08")))
